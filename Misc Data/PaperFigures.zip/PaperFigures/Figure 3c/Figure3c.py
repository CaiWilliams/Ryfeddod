from Main import *
import pandas as pd
import numpy as np

Si_Wp = 0.245
Si_Eff = 0.2
DSSC_M = 65.09
DSSC_Eff = 0.0078
Area_M = 0.13
Capacity_MW = 11798.29958077
Capacity_W = Capacity_MW * 1e6

NG = Setup('C:\\Users\Cai Williams\PycharmProjects\Ryfeddod\Data\\2016RawT.NGM', 'C:\\Users\Cai Williams\PycharmProjects\Ryfeddod\Data\Devices\DSSC.csv', 53.13359, -1.746826)
NG = Scaling(NG, 1, 1, 0, 0)

def DSSCperM_toW(Manufacturning, Materials, Efficiency):
    return (Manufacturning*Materials)/(1000*Efficiency)

def Area(Capacity, Eff, Tilt, Width, Elev):
    RowWidth = Elev + (np.cos(np.radians(Tilt)) * Width)
    NofPanels = (1000 * Capacity)/Eff
    Area = (((((1.92 * np.cos(np.radians(Tilt))) * 2) + RowWidth) * 0.99)/2) * NofPanels
    return Area

DSSC_Wp_Low = DSSCperM_toW(1.2, DSSC_M, DSSC_Eff)
DSSC_Wp_Mean = DSSCperM_toW(1.3, DSSC_M, DSSC_Eff)
DSSC_Wp_High = DSSCperM_toW(1.4, DSSC_M, DSSC_Eff)

X = np.linspace(0,2,100)

Initial_Cost = (Capacity_W * Si_Wp) + (Area(Capacity_MW * 1, Si_Eff, 39, 1.968, 7) * Area_M)

Si_Cost = (X * Capacity_W * Si_Wp) + (Area(Capacity_MW * X, Si_Eff, 39, 1.968, 7) * Area_M)
DSSC_Cost_Low = (X * Capacity_W * DSSC_Wp_Low) + (Area(Capacity_MW * X, DSSC_Eff, 39, 1.968, 7) * Area_M)
DSSC_Cost_Mean = (X * Capacity_W * DSSC_Wp_Mean) + (Area(Capacity_MW * X, DSSC_Eff, 39, 1.968, 7) * Area_M)
DSSC_Cost_High = (X * Capacity_W * DSSC_Wp_High) + (Area(Capacity_MW * X, DSSC_Eff, 39, 1.968, 7) * Area_M)


DSSC_CO2 = np.zeros(len(X))
G = np.zeros(len(X))
for idx,x in enumerate(X):
    NG = Scaling(NG,1,1,x,x)
    DNG = Dispatch(NG)
    C = np.sum(DNG.CarbonEmissions)/2 * 1e-9
    for Asset in DNG.Distributed.Mix['Technologies']:
        if Asset['Technology'] == 'Solar':
            G[idx] = G[idx] + np.sum(Asset['Generation'] / 1000000 / 2)
        if Asset['Technology'] == 'SolarBTM':
            G[idx] = G[idx] + np.sum(Asset['Generation'] / 1000000 / 2)
        if Asset['Technology'] == 'SolarNT':
            G[idx] = G[idx] + np.sum(Asset['Generation'] / 1000000 / 2)
        if Asset['Technology'] == 'SolarBTMNT':
            G[idx] = G[idx] + np.sum(Asset['Generation'] / 1000000 / 2)
    DSSC_CO2[idx] = C
    DSSC_G = G
DSSC_CO2 = DSSC_CO2[0] - DSSC_CO2

Si_CO2 = np.zeros(len(X))
G = np.zeros(len(X))
for idx,x in enumerate(X):
    NG = Scaling(NG,1+x,1+x,0,0)
    DNG = Dispatch(NG)
    for Asset in DNG.Distributed.Mix['Technologies']:
        if Asset['Technology'] == 'Solar':
            G[idx] = G[idx] + np.sum(Asset['Generation'] / 1000000 / 2)
        if Asset['Technology'] == 'SolarBTM':
            G[idx] = G[idx] + np.sum(Asset['Generation'] / 1000000 / 2)
        if Asset['Technology'] == 'SolarNT':
            G[idx] = G[idx] + np.sum(Asset['Generation'] / 1000000 / 2)
        if Asset['Technology'] == 'SolarBTMNT':
            G[idx] = G[idx] + np.sum(Asset['Generation'] / 1000000 / 2)
    C = np.sum(DNG.CarbonEmissions) / 2 * 1e-9
    Si_CO2[idx] = C
    Si_G = G
Si_CO2 = Si_CO2[0] - Si_CO2


plt.rcParams["figure.dpi"] = 300
plt.plot(X, Si_CO2, c="c")
plt.plot(X, DSSC_CO2, c="m")
plt.ylabel("Annual CO$_2$e Emissions Saved (Mt)")
plt.xlabel("C")
plt.twinx()
plt.plot(X, Si_G, c="c", linestyle='--')
plt.plot(X, DSSC_G, c="m", linestyle='--')

plt.xlabel("C")
plt.ylabel("Annual Generation (TWh)")
plt.tight_layout()
plt.savefig("Figure3c.svg")
plt.savefig("Figure3c.png")
plt.show()