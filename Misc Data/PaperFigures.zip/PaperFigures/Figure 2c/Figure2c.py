from Main import *
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt


def SweepCarbon(NG,C_Start,C_End,S_Start,S_End):

    steps = 100
    Conv = np.linspace(C_Start,C_End, steps)
    Scav = np.linspace(S_Start,S_End, steps)

    Gen = np.ndarray(shape=(steps, 1))
    Gen.fill(0)

    for idx in range(0,steps,1):
        print(Scav[idx])
        NG = Scaling(NG, Conv[idx]+1, Conv[idx]+1, Scav[idx], Scav[idx])
        DNG = Dispatch(NG)

        Gen[idx] = Gen[idx] + (np.sum(DNG.CarbonEmissions) / 2 * (1*10**-9))
    Gen = Gen[0] - Gen[:]
    return Conv, Scav, Gen


NG = Setup('C:\\Users\Cai Williams\PycharmProjects\Ryfeddod\Data\\2016RawT.NGM', 'C:\\Users\Cai Williams\PycharmProjects\Ryfeddod\Data\Devices\DSSC.csv', 53.13359, -1.746826)
C, S, Gen = SweepCarbon(NG,0,0,0,2)
plt.plot(S,Gen,c="m")
C, S, Gen = SweepCarbon(NG,0,2,0,0)
plt.plot(C,Gen,"c")
#plt.xlim(left=0, right=2)
plt.ylim(bottom=0)
plt.xlabel("C")
plt.ylabel("CO$_{2}e$ Emissions Savings (Mt)")
plt.tight_layout()
plt.savefig("CarbonSavings.svg")
plt.savefig("CarbonSavings.png")
plt.show()