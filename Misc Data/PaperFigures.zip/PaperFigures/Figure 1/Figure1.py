import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit

def func(m, x, c):
    return (m*x) + c

def IrradianceDependance(File):
    JV = pd.read_csv(File)
    JV1000 = JV.iloc[1:, 0:2].set_axis(['Voltage', 'Current'], axis=1, inplace=False).dropna().astype(float)
    JV800 = JV.iloc[1:, 2:4].set_axis(['Voltage', 'Current'], axis=1, inplace=False).dropna().astype(float)
    JV600 = JV.iloc[1:, 4:6].set_axis(['Voltage', 'Current'], axis=1, inplace=False).dropna().astype(float)
    JV400 = JV.iloc[1:, 6:8].set_axis(['Voltage', 'Current'], axis=1, inplace=False).dropna().astype(float)
    JV200 = JV.iloc[1:, 8:10].set_axis(['Voltage', 'Current'], axis=1, inplace=False).dropna().astype(float)

    X = np.array([200, 400, 600, 800, 1000])
    Y = np.zeros(len(X))

    Y[0] = max(JV200['Current'] * JV200['Voltage']) / (200 * 1.73)
    Y[1] = max(JV400['Current'] * JV400['Voltage']) / (400 * 1.73)
    Y[2] = max(JV600['Current'] * JV600['Voltage']) / (600 * 1.73)
    Y[3] = max(JV800['Current'] * JV800['Voltage']) / (800 * 1.73)
    Y[4] = max(JV1000['Current'] * JV1000['Voltage']) / (1000 * 1.73)
    #plt.plot(X,Y*100)
    x = np.linspace(0,1000,10000)
    popt, pcov = curve_fit(func, X, Y)
    plt.plot(x, func(x, *popt)*100, c="c")
    return

def ConnstantPower(Power):
    X = np.linspace(0,1000,1000)
    Y = (np.ones(len(X)) * Power) / X
    Y = Y[np.isfinite(Y)]
    #Y = np.clip(Y,0,1)
    plt.plot(X[1:],Y*100, linestyle='--', c="black")
    return


plt.rcParams["figure.dpi"] = 300
plt.rcParams["figure.figsize"] = (4, 6)
IrradianceDependance('C:\\Users\Cai Williams\PycharmProjects\Ryfeddod\LGNeoN2Black.csv')
Bangor = pd.read_csv('C:\\Users\Cai Williams\PycharmProjects\Ryfeddod\Data\Devices\DSSCPCE.csv')
plt.plot(Bangor['Irradiance'][70:],Bangor['Enhanced'][70:]*100,c="m")
ConnstantPower(100)
plt.ylim(bottom=0,top=25)
plt.yscale('symlog')
plt.yticks(np.arange(0,25)[::4], np.arange(0,25)[::4])
plt.ylabel('Power Conversion Efficiency (%)')
plt.xlabel('Irradiance (Wm$^{2}$)')
plt.tight_layout()
plt.savefig("Figure1_100.png")
plt.savefig("Figure1_100.svg")
plt.show()